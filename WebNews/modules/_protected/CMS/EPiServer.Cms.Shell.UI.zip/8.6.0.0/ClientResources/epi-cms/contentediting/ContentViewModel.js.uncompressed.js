﻿define("epi-cms/contentediting/ContentViewModel", [
    // Dojo
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/_base/lang",
    "dojo/_base/kernel",
    "dojo/topic",
    "dojo/on",
    "dojo/when",
    "dojo/promise/all",
    "dojo/Stateful",
    "dijit/Destroyable",

    // EPi Framework
    "epi",
    "epi/dependency",
    "epi/datetime",
    "epi/string",
    "epi/shell/UndoManager",
    "epi/shell/conversion/ObjectConverterRegistry",
    "epi/shell/widget/dialog/Alert",
    "epi/shell/Stateful",

    // EPi CMS
    "../ApplicationSettings",
    "./ContentActionSupport",
    "./ContentEditingValidator",
    "./ContentModelServerSync",
    "./Operation",

    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting",
    "epi/i18n!epi/cms/nls/episerver.cms.components.versions"
],


function (
// Dojo
    array,
    connect,
    declare,
    Deferred,
    lang,
    kernel,
    topic,
    on,
    when,
    all,
    Stateful,
    Destroyable,

// EPi Framework
    epi,
    dependency,
    epiDate,
    epiString,
    UndoManager,
    ObjectConverterRegistry,
    Alert,
    EpiStateful,

// EPi CMS
    ApplicationSettings,
    ContentActionSupport,
    ContentEditingValidator,
    ContentModelServerSync,
    Operation,

// Resources
    res,
    resVersions
) {

    return declare([Stateful, Destroyable], {
        // tags:
        //      internal

        // PUBLIC
        contentModel: null,

        metadata: null,

        syncService: null,

        editorFactory: null,

        syncInterval: 10000,

        validator: null,

        contentDataStore: null,

        profileHandler: null,

        languageContext: null,

        // PRIVATE
        _converterRegistry: null,

        _contentVersionStore: null,

        _syncRetryTimeout: 60000,

        undoManager: null,

        contextTypeName: "",

        contentLink: null,

        contentData: null,

        viewName: null,

        isCreatingNewVersion: false,

        hasUndoSteps: false,
        hasRedoSteps: false,
        isValid: true,
        hasPendingChanges: false,
        lastSaved: null,
        isSaved: true,
        isSaving: false,
        isOnline: true,
        hasErrors: false,
        isChangingContentStatus: false,

        _isSuspended: false,

        constructor: function () {
            this.contentModel = new EpiStateful();
        },

        postscript: function () {
            this.inherited(arguments);

            // resolve dependency variables
            this.profileHandler = this.profileHandler || dependency.resolve('epi.shell.Profile');
            this.metadataManager = this.metadataManager || dependency.resolve('epi.shell.MetadataManager');
            this.projectService = this.projectService || dependency.resolve("epi.cms.ProjectService");

            this.currentContentLanguage = this.currentContentLanguage || ApplicationSettings.currentContentLanguage;
            this.contentDataStore = this.contentDataStore || dependency.resolve("epi.storeregistry").get("epi.cms.contentdata");

            if (!this._contentVersionStore) {
                this._contentVersionStore = dependency.resolve("epi.storeregistry").get("epi.cms.contentversion");
            }

            this.undoManager = this.undoManager || new UndoManager();
            this.validator = this.validator || new ContentEditingValidator({ contextId: this.get("contentLink"), contextTypeName: this.contextTypeName });

            if (!this.syncService) {
                this._createSyncService();
            }

            // observe and copy these properties to this object
            var updater = lang.hitch(this, function (name, oldVal, newVal) { this.set(name, newVal); });

            this._operation = new Operation();

            this.own(
                this.syncService.watch("hasPendingChanges", updater),
                this.validator.watch("isValid", updater),
                this.validator.watch("hasErrors", updater),
                this.undoManager.watch("hasUndoSteps", updater),
                this.undoManager.watch("hasRedoSteps", updater),
                on(this._operation, "commit", lang.hitch(this, this._commitChanges))
            );
        },

        setActiveProperty: function (name) {
            // summary:
            //      Set property to active, which would bring up property's editor.
            // name: [String]
            //      Property name. Can also be "dot notation" name if it is sub property of a block property.
            // tags:
            //      public

            this.onSetActiveProperty(name);
        },

        suspend: function () {
            // summary:
            //      Suspends the editing for this view model.

            this._isSuspended = true;

            this.onContentChange();
            this.onSuspend();
        },

        onSuspend: function () {
            // summary:
            //  Raise onSuspend current view model
        },

        wakeUp: function () {
            // summary:
            //      Wake the suspended content view model up.

            this._isSuspended = false;
        },

        destroy: function () {

            this.clear();

            this.inherited(arguments);
        },


        clear: function () {
            this.undoManager.clear();
        },

        _createSyncService: function () {
            // summary:
            //      Creates and returns a new sync service instance.
            // tags:
            //      private

            var syncService = new ContentModelServerSync({
                contentLink: this.get("contentLink"),
                contentDataStore: this.contentDataStore
            });

            this.syncService = syncService;
        },

        connectLocal: function (targetArray, obj, evt, listener) {
            if (!lang.isArray(targetArray)) {
                throw Error("First argument to connectLocal must be an Array");
            }

            return targetArray.push(connect.connect(obj, evt, this, listener));
        },

        disconnectLocal: function (targetArray) {
            if (lang.isArray(targetArray)) {
                var listener;
                while (listener = targetArray.pop()) {
                    connect.disconnect(listener);
                }
            }
        },

        resetNotifications: function () {
            this.validator.clearErrorsBySource(this.validator.validationSource.client);
        },

        beginOperation: function () {
            // summary:
            //      Start a multi property operation where all property changes are should be handled as one undo step.

            this._operation.begin();
        },

        endOperation: function () {
            // summary:
            //      End a multi property operation, creating an undo step.

            this._operation.end();
        },

        abortOperation: function () {
            // summary:
            //      Abort an ongoing multi property operation.

            this._operation.abort();
        },

        getProperty: function (propertyName) {
            return this.contentModel.get(propertyName);
        },

        setProperty: function (propertyName, value, oldValue) {
            this._setModelProperty(propertyName, value, oldValue);
        },

        publishProperty: function (propertyName, value) {
            // summary:
            //      Save a property value to the published version.
            // propertyName: String
            //      The property name
            // value:
            //      The property value

            kernel.deprecated("epi-cms/contentediting/ContentViewModel::publishProperty", "use ::saveAndPublishProperty instead");
            return this.saveAndPublishProperty(propertyName, value);
        },

        saveAndPublishProperty: function (propertyName, value) {
            // summary:
            //      Save a property value to the published version. The change is also saved on the current version.
            // propertyName: String
            //      The property name
            // value:
            //      The property value

            // sync change to syncservice
            return when(this.syncService.saveAndPublishProperty(propertyName, value), lang.hitch(this, function (result) {

                // Update model
                this.contentModel.set(propertyName, value);

                // updata data store
                return when(all([
                    this.contentDataStore.refresh(result.contentLink),
                    result.publishedContentLink ? this.contentDataStore.refresh(result.publishedContentLink) : null
                ]),
                lang.hitch(this, function (promiseResult) {
                    var contentData = promiseResult[0];
                    this.set("contentData", contentData);

                    return result;
                }));
            }));
        },

        _commitChanges: function (/*Array*/ properties) {
            // summary:
            //      Schedules the supplied properties to the server and creates ONE undo step for the changes

            var inverseProperties = array.map(properties, function (item) {
                return {
                    propertyName: item.propertyName,
                    value: item.oldValue,
                    oldValue: item.value
                };
            });

            this.undoManager.createStep(this, this._saveProperties, [inverseProperties], 'Edit properties');
        },

        _saveProperties: function (properties) {
            // summary:
            //      Updates the model with an array of properties as one "unit" causing one undo step.
            //      Primaryly used as undo/redo callback

            this.beginOperation();

            array.forEach(properties, function (p) {
                this._setModelProperty(p.propertyName, p.value, p.oldValue);
            }, this);

            this.endOperation();
        },

        _setModelProperty: function (propertyName, value, oldValue) {
            // summary:
            //      Sets a property value on the content model and adds a save operation to the internal operation object

            this.set("isSaved", false);

            this._operation.save({
                propertyName: propertyName,
                value: value,
                oldValue: (oldValue === undefined) ? this.contentModel.get(propertyName) : oldValue
            });

            this.contentModel.set(propertyName, value);

            // Add the property to the sync queue
            this.syncService.scheduleForSync(propertyName, value);

            this.onPropertyEdited(propertyName, value);
        },

        onPropertyEdited: function (propertyName, value) {
            // summary:
            //      Called when a property has been edited.
            //
            // propertyName: String
            //      Name of the property
            //
            // value: String|Object
            //      The new value
            //
            // tags:
            //      public
        },

        onPropertySaved: function (propertyName, value) {
            // summary:
            //      Raised when a property value has been saved to the server
            //
            // propertyName: String
            //      Name of the saved property
            //
            // value: String|Object
            //      The saved value
            //
            // tags: internal
        },

        _onSynchronizeSuccess: function (contentLink, properties, results) {
            // summary:
            //    Handler when a property has been successfully synchronized
            // contentLink:
            //      The contentLink
            // properties:
            //      Properties synchronized

            array.forEach(properties, lang.hitch(this, function (property) {
                this.validator.clearPropertyErrors(property.name, this.validator.validationSource.server);
                // updata data store
                this._patchContentDataStore(contentLink, property.name, null, property.value);
                this.onPropertySaved(property.name, property.value);
            }));

            this.validator.setGlobalErrors(results.validationErrors, this.validator.validationSource.server);
        },


        _onSynchronizeFailure: function (contentLink, properties, message, results) {
            // summary:
            //      Handler a property couldn't be synchronized due to server rejecting the data, for
            //      instance if data isn't valid
            // contentLink:
            //      The contentLink
            // properties:
            //      Properties
            // message:
            //      A message why it couldn't update
            // results:
            //      The results of the update including any global validation errors.
            // tags:
            //      private

            array.forEach(properties, function (property) {
                if ("successful" in property) {
                    if (property.successful) {
                        this.validator.clearPropertyErrors(property.name, this.validator.validationSource.server);
                    }
                    else {
                        this.validator.setPropertyErrors(property.name, [{ "errorMessage": property.validationErrors, severity: this.validator.severity.error }], this.validator.validationSource.server);
                    }
                } else {
                    // Keep everything as they are, we didn't get any response with error messages
                }
            }, this);

            //If we have a result set the global validation errors
            if (results) {
                if (results.validationErrors) {
                    this.validator.setGlobalErrors(results.validationErrors, this.validator.validationSource.server);
                } else {
                    this.validator.clearGlobalErrors(this.validator.validationSource.server);
                }
            }
        },

        _contentLinkChanged: function (oldContentLink, newContentLink) {

            // store the latest newContentLink, could have changed during sync, ie when first changing a property
            this.set("contentLink", newContentLink);

            this.syncService.contentLink = newContentLink;

            // propagate new contentlink
            this.validator.setContextId(newContentLink);

            if (!this._isSuspended) {
                // note that our view component, OPE or form must check if we're the sender?
                // or just skip when a content link changed
                var contextParameters = { uri: "epi.cms.contentdata:///" + newContentLink };
                topic.publish("/epi/shell/context/request", contextParameters, { sender: this, contextIdSyncChange: true, trigger: "internal" });
            }
        },

        ensureWritableVersion: function () {
            // summary:
            //      Ensures that we are editing a writable version
            //
            //  tags:
            //      private

            var contentLink = this.get("contentLink");

            if (!this.contentData.isNewVersionRequired) {
                return contentLink;
            }


            if(this._isCreatingNewVersionDeferred && !this._isCreatingNewVersionDeferred.isFulfilled()) {
                return this._isCreatingNewVersionDeferred.promise;
            } else {
                this._isCreatingNewVersionDeferred = new Deferred();
            }

            this.isCreatingNewVersion = true;


            // TODO: handle reject of creating new version
            when(this._contentVersionStore.put({ originalContentLink: contentLink }), lang.hitch(this, function (newVersion) {

                //Load the new version
                //NOTE:     we need to refresh contentData before we resolve because isNewVersionRequired
                //          is returned with the contentData, if we don't update contentData before resolving we
                //          can end up in a situation where we keep producing new versions with every sync call
                //          since isNewVersionRequired stays true
                this.contentDataStore.refresh(newVersion.contentLink).then(lang.hitch(this, function(contentData){
                    this.set("contentData", contentData);
                })).always(lang.hitch(this, function () {
                    this.isCreatingNewVersion = false;
                    this._contentLinkChanged(contentLink, newVersion.contentLink);
                    this._isCreatingNewVersionDeferred.resolve(newVersion);
                }));

            }), lang.hitch(this, function (error) {
                console.error(error);

                this.isCreatingNewVersion = false;
                this._isCreatingNewVersionDeferred.reject(error);
            }));

            return this._isCreatingNewVersionDeferred.promise;
        },

        validate: function () {
            // summary:
            //      Validate the model
            //
            //  tags:
            //      public

            var def;
            if (!this.validator) {
                def = new Deferred();
                def.resolve();
            }
            else {
                def = this.validator.validate();
            }

            return def;
        },

        revertToPublished: function () {
            // summary:
            //      Revert to published version
            // tags:
            //      Public

            var contentLink = this.get("contentLink");

            when(this._contentVersionStore.remove(contentLink),
                lang.hitch(this, function () {
                    this._loadPublishedVersion(contentLink);
                }),
                lang.hitch(this, function (error) {
                    var errorMessage;
                    if (error.status === 403) {
                        // This version already published
                        errorMessage = resVersions.deleteversion.cannotdeletepublished;
                    }
                    else if (error.status === 404) {
                        // This version does not exist
                        errorMessage = res.versionstatus.versionnotfound;
                    }
                    if (errorMessage) {
                        this.dialog = new Alert({
                            description: errorMessage,
                            onAction: lang.hitch(this, function () {
                                this._loadPublishedVersion(contentLink);
                            })
                        });
                        this.dialog.show();
                    }
                })
            );
        },

        _loadPublishedVersion: function (contentLink) {
            // summary:
            //      Get published version and reload
            // tags:
            //      Private
            when(this._contentVersionStore.query({ contentLink: contentLink, language: this.languageContext ? this.languageContext.language : "", query: "getpublishedversion" }),
                lang.hitch(this, function (result) {
                    if (result !== null) {
                        var contextParameters = { uri: "epi.cms.contentdata:///" + result.contentLink, context: this };
                        topic.publish("/epi/shell/context/request", contextParameters, { sender: this, forceReload: true });
                    }
                }));
        },

        createDraft: function () {

            var contentLink = this.get("contentLink"),
                setCommonDraft =
                    this.contentData.isCommonDraft &&
                    this.contentData.status === ContentActionSupport.versionStatus.DelayedPublish &&
                    !this.projectService.isProjectModeEnabled;

            return when(this._contentVersionStore.put({ originalContentLink: contentLink, isCommonDraft: setCommonDraft }), lang.hitch(this, function (newVersion) {
                var contextParameters = { uri: "epi.cms.contentdata:///" + newVersion.contentLink, context: this };
                topic.publish("/epi/shell/context/request", contextParameters, { sender: this });
                topic.publish("/epi/cms/content/statuschange/", "common-draft", { id: newVersion.contentLink });
            }));

        },

        editCommonDraft: function () {
            // summary:
            //      Get common draft version and reload
            // tags:
            //      Public
            var contentLink = this.get("contentLink");

            return when(this._contentVersionStore.query({ contentLink: contentLink, query: "getcommondraftversion" }), lang.hitch(this, function (commonDraftVersion) {
                var contextParameters = { uri: "epi.cms.contentdata:///" + commonDraftVersion.contentLink, context: this };
                topic.publish("/epi/shell/context/request", contextParameters, { sender: this });
            }));
        },

        _populateContentModel: function (data, metadata) {
            var props = {},
                converterType,
                converter;

            for (var propertyName in data) {
                var propertyMetadata = metadata.getPropertyMetadata(propertyName);
                var propertyValue = data[propertyName];
                if (propertyMetadata.hasSubProperties()) {
                    props[propertyName] = this._populateContentModel(propertyValue, propertyMetadata);
                }
                else {
                    // default
                    props[propertyName] = propertyValue;

                    // check for converter
                    converterType = propertyMetadata.customEditorSettings.converter;
                    if (converterType) {
                        converter = ObjectConverterRegistry.getConverter(converterType, "runtimeType");
                        if (converter) {
                            // bind converted value instead
                            props[propertyName] = converter.convert(converterType, "runtimeType", propertyValue);
                        }
                    }
                }
            }
            return props;
        },

        getPropertyMetaData: function (propertyName) {
            // summary:
            //      Return metadata of a property.
            //
            // propertyName: [String]
            //      The property name
            //
            // return: [Object|Deferred]
            //      Returns the metadata object if content metadata has already resolved.
            //      Otherwise returns a deferred which resolves to the property metadata when content metadata is loaded.
            //
            // tags:
            //      public

            return when(this._getMetadata(), function (metadata) {
                return metadata.getPropertyMetadata(propertyName);
            });
        },

        reload: function () {
            // summary:
            //      Reloads the metadata and content data for the model
            //
            // return: [Promise]
            //      Returns a promise when the data has been reloaded
            //
            // tags:
            //      public

            return when(all([
                this.contentDataStore.get(this.get("contentLink")),
                this._getMetadata(true)]),
                lang.hitch(this, function (data) {
                    var contentData = data[0],
                        metadata = data[1];

                    this.set("contentData", contentData);

                    var contentModel = this.get("contentModel");
                    var model = this._populateContentModel(contentData.properties, metadata);

                    for (var name in model) {
                        // Only update changed values, otherwise watches are called for all properties
                        if (model.hasOwnProperty(name) && !epi.areEqual(contentModel.get(name), model[name])) {
                            contentModel.set(name, model[name]);
                        }
                    }
                })
            );
        },

        getContentModelAndMetadata: function () {
            // summary:
            //      Reloads the metadata and content data for the model
            // tags:
            //      deprecated

            kernel.deprecated("epi-cms/contentediting/ContentViewModel::getContentModelAndMetadata", "use ::reload instead");
            return this.reload();
        },

        getMetadataThenUpdateModel: function () {
            // summary:
            //      Reloads the metadata and content data for the model
            // tags:
            //      deprecated

            kernel.deprecated("epi-cms/contentediting/ContentViewModel::getMetadataThenUpdateModel", "use ::reload instead");
            return this.reload();
        },

        _getMetadata: function (reload) {
            // summary:
            //      Returns the metadata for the content
            // reload: [Boolean]
            //      Flag inidicating if the metadata should be reloaded or not
            // return: [Object|Promise]
            //      Returns the metadata object if content metadata has already resolved.
            //      Otherwise returns a deferred which resolves to the  content metadata is loaded.
            // tags:
            //      private

            var metadata = this.get("metadata");
            if (!reload && metadata) {
                return metadata;
            }

            var self = this;
            return when(this.metadataManager.getMetadataForType("EPiServer.Core.ContentData", { contentLink: this.get("contentLink") }),
                function (metadata) {
                    self.set("metadata", metadata);

                    return metadata;
                });
        },

        save: function () {
            if (!this.isOnline) {
                var def = new Deferred();

                def.resolve(true);

                return def;
            }
            return this._save();
        },

        _save: function () {
            var def = new Deferred(),
                onSuccess = lang.hitch(this, function (result) {
                    if (result) {
                        if (result.successful) {
                            this._onSynchronizeSuccess(result.contentLink, result.properties, result);
                        } else {
                            this._onSynchronizeFailure(result.contentLink, result.properties, result.validationErrors, result);
                        }
                        if (result && result.hasContentLinkChanged) {
                            this._contentLinkChanged(result.contentLink, result.oldContentLink);
                        }
                    }

                    this.set("isOnline", true);
                    this.set("lastSaved", new Date());
                    this.set("isSaving", false);
                    this.set("isSaved", true);

                    def.resolve(true);
                }),
                onError = lang.hitch(this, function (result) {

                    this.set("hasErrors", true);
                    this.set("isSaving", false);
                    this.set("isSaved", false);
                    this.set("isOnline", false);

                    if (result) {
                        //If we do not have any newer change to the property, schedule a new sync for them
                        array.forEach(result.properties, lang.hitch(this, function (property) {
                            if (!this.syncService.pendingSync(property.name)) {
                                this.syncService.scheduleForSync(property.name, property.value);
                            }
                        }));
                    }

                    setTimeout(lang.hitch(this, function () {
                        this.set("isOnline", true);
                        this._save();
                    }), this._syncRetryTimeout);

                    def.reject(result);
                });

            //Make sure that we have a version that we can make changes to
            if (!this.hasPendingChanges) {
                onSuccess();
            } else {

                when(this.ensureWritableVersion()).then(lang.hitch(this, function () {
                    this.set("isSaving", true);
                    return this.syncService.save();
                })).then(onSuccess).otherwise(onError);

            }
            return def;
        },

        undo: function () {
            this.undoManager.undo();
        },

        redo: function () {
            this.undoManager.redo();
        },

        _patchContentDataStore: function (contentLink, propertyName, oldValue, newValue) {
            // summary:
            //      Updates the named named property in the current content data store with value in newValue

            var properties = {};

            lang.setObject(propertyName, newValue, properties);

            return this.contentDataStore.patchCache({
                contentLink: contentLink,
                changedBy: this.profileHandler.userName,
                saved: epiDate.serialize(new Date()),
                properties: properties
            });
        },

        changeContentStatus: function (status) {
            var contentLink = this.get("contentLink");
            var def = new Deferred();

            // This will notify other content that we are in changing state.
            this.set("isChangingContentStatus", true);

            var onSuccess = lang.hitch(this, function (result) {
                var success = result && result.success;
                var validator = this.validator;
                if (success) {
                    // Set lastSaved to null after publishing, ready to publish and Schedule to publish the content
                    if (status == ContentActionSupport.action.Publish
                        || status == ContentActionSupport.action.CheckIn
                        || status == (ContentActionSupport.saveAction.CheckIn | ContentActionSupport.saveAction.DelayedPublish | ContentActionSupport.saveAction.ForceCurrentVersion)) {
                        this.set("lastSaved", null);
                    }
                    if (validator) {
                        validator.clearGlobalErrors(validator.validationSource.server);
                    }
                    var resolveArgs = { id: result.id, oldId: contentLink };
                    topic.publish("/epi/cms/content/statuschange/", status, resolveArgs);
                    def.resolve(resolveArgs);
                } else {
                    if (result && result.validationErrors) {
                        // add to validator
                        if (validator) {
                            validator.setGlobalErrors(result.validationErrors, validator.validationSource.server);
                            validator.validate();
                        }

                        // reject with empty value, we took care of the validations errors
                        def.reject(null);
                    } else {
                        def.reject((result && result.errorMessage) ? result.errorMessage : res.publish.error);
                    }
                }

                this.set("isChangingContentStatus", false);
            });

            var onError = lang.hitch(this, function (result) {
                topic.publish("/epi/cms/action/showerror"); //TODO: Copy from PageDataController to make the system working as before. But, why we need it!!!
                def.reject((result && result.errorMessage) ? result.errorMessage : res.publish.error);

                this.set("isChangingContentStatus", false);
            });

            this.onContentChange();

            // Validate, save pending change, then execute changestatus server method.
            when(this.validate(), lang.hitch(this, function () {
                when(this.save(), lang.hitch(this, function () {
                    when(this.contentDataStore.executeMethod("ChangeStatus", this.get("contentLink"), { action: status }), onSuccess, onError);
                }), onError);
            }), onError);

            return def;
        },

        onContentChange: function () {
            // summary:
            //      Raised before making changes that will eventually change content
            // tags:
            //      callback
        },

        hasEditAccess: function () {
            // summary:
            //      Check if current user has access right to edit the content
            return ContentActionSupport.hasAccess(this.contentData.accessMask, ContentActionSupport.accessLevel.Edit);
        },

        hasAccess: function (action) {
            // summary:
            //      Check if current user has access on the active content using the given action.
            // remark:
            //      This method cannot be overriden by plugins. Use when we need to check core conditions only.

            // languageContext is null if the content or content provider does not have multi language support
            // in this case allow editing matter which language is active
            var canEditLanguage = !this.languageContext || !this.languageContext.isTranslationNeeded;
            return canEditLanguage && ContentActionSupport.isActionAvailable(this.contentData, action || ContentActionSupport.action.Edit, ContentActionSupport.providerCapabilities.Edit);
        },

        canTranslateContent: function () {

            if (this.viewLanguage && this.languageContext && this.viewLanguage != this.currentContentLanguage) {
                return false;
            }

            return true;
        },

        canChangeContent: function (action) {
            // summary:
            //      Check if current user can change on the active content using
            //      the given action.
            // action: String
            //      The action to check.
            // returns: Boolean
            //      A boolean which indicates whether the current user can
            //      change the current content using the given action.
            // tags:
            //      internal

            var isPartOfProject = this.projectService.isProjectModeEnabled && this.contentData.isPartOfAnotherProject;

            return !isPartOfProject && this.canEditCurrentLanguage() && this.hasAccess(action);
        },

        canEditCurrentLanguage: function () {
            // summary:
            //      Check if the current content language can be edited in the current language context.
            // tags:
            //      public
            if (!this.languageContext) {
                return true;
            }

            return this.languageContext.language == this.currentContentLanguage;
        },

       _contentDataSetter: function(contentData) {
           this.contentData = contentData;
           if (contentData.contentLink !== undefined) {
               this.set("contentLink", contentData.contentLink);
           }
       }
    });
});
