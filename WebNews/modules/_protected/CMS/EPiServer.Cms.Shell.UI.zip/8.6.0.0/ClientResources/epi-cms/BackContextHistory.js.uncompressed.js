﻿define("epi-cms/BackContextHistory", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/store/Memory",

    "epi/shell/ContextHistory",
    "epi/shell/ViewSettings"
],
function (
    declare,
    lang,

    Memory,

    ContextHistory,
    ViewSettings
) {

    return declare([ContextHistory], {
        // summary:
        //      Context history for back only action
        // tags:
        //      internal

        createStore: function () {
            // summary:
            //      Create new store
            // tags:
            //      override

            return new Memory({
                data: [],
                idProperty: "index"
            });
        },

        onContextChanged: function (response, callerData, request) {
            // summary:
            // tags:
            //      override

            if (callerData && callerData.trigger === "back") {
                this._removeLastItem();
                return;
            }

            this.inherited(arguments);
        },
        getPreviousContent: function() {
            // summary:
            //      Return previous content or default content
            // tags:
            //      public

            var i, context,
                result = this.store.query({}, {
                    sort: [{
                        attribute: "dateAdded",
                        descending: true
                    }]
                }),
                contextHistory = (result && result.length > 0) ? result : null;
            
            if (contextHistory) {
                for (i = 0; i < contextHistory.length; i++) {
                    context = contextHistory[i];
                    if (context.uri && context.uri.indexOf("epi.cms.project:///") === -1) {
                        return {
                            uri: context.uri
                        };
                    }
                }
            }
            //Return default context
            return { uri: ViewSettings.settings.defaultContext };

        },

        getPrevious: function () {
            // summary:
            //      Return previous content of currently loaded content.
            // tags:
            //      public

            var results = this.store.query({}, {
                count: 2, // Get current content and previous content
                sort: [{
                    attribute: "dateAdded",
                    descending: true
                }]
            });

            // Get previous content from sorted descending array.
            return (results && results.length > 1) ? results[1] : null;
        },

        _updateStore: function(response) {
            var lastItem = this._getLastItem();
            if (lastItem && lastItem.uri === response.versionAgnosticUri) {
                return;
            }

            this.inherited(arguments);
        },

        _getLastItem: function () {
            // summary:
            //     Returns the just previously added item from the store
            // tags:
            //      protected

            if (this.store && this.store.data && this.store.data.length > 0) {
                return this.store.data[this.store.data.length - 1];
            }

            return null;
        },

        _removeLastItem: function () {
            // summary:
            //     Removes the last added item from the store
            // tags:
            //      protected

            var lastItem = this._getLastItem();
            if (lastItem) {
                this.store.remove(this.store.getIdentity(lastItem));
            }
        }
    });
});