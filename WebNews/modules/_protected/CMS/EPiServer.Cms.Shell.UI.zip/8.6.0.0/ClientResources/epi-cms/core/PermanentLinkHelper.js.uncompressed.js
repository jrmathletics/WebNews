﻿define("epi-cms/core/PermanentLinkHelper", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/kernel",
    "dojo/Deferred",
    "dojo/_base/lang",

    "dojo/when",

// epi
    "epi/dependency"
],

function (
// dojo
    declare,
    kernel,
    Deferred,
    lang,

    when,

// epi
    dependency
) {

    return {
        // summary:
        //      Get the content from a permanent link
        // tags:
        //      public

        toPermanentLink : function (/*Object*/content, /*String*/mode) {

            // summary:
            //      Converts a content data object to it's permanent link form.
            // description:
            //      The link created will be in the format "/link/{contentGuid}.aspx". Since everything
            //      is now content all links can be resolved with the .aspx extension.
            // tags:
            //      public

            kernel.deprecated("toPermanentLink(...)", "permanentLink is provided on the contentData.permanentUrl", "8");

            if(!content) {
                return undefined;
            }

            return content.permanentLink;
        },

        isPermanentLink: function (/*String*/link) {
            // summary:
            //      Test whether given string is in permanent link format
            // tags:
            //      public

            kernel.deprecated("isPermanentLink(...)", "isPermanentLink(...) will be removed", "8");

            // If the link contains "/link/" and follow with "<guid>.aspx" then true otherwise false
            return (/(\/link\/)(?=([0-9a-z]{32})(\.aspx))/i).test(link);
        },

        getContent: function (/*String*/link, /*Object*/options) {
            // summary:
            //      Get linked content data with the permanent link
            // tags:
            //      public

            if (!link) {
                return null;
            }

            var registry = dependency.resolve("epi.storeregistry"),
                store = registry.get("epi.cms.content.light"),
                query = lang.mixin({
                    "query": "getcontentbypermanentlink",
                    "permanentLink": link,
                    "stripWorkId": true //TODO: Remove when #119828 has been fixed
                }, options || {});

            return when(store.query(query)).then(lang.hitch(this, function (contents) {
                return contents && contents instanceof Array ? contents[0] : contents;
            }));
        }
    };
});